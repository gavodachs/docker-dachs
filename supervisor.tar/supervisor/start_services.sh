#!/bin/bash
#supervisorctl start postgres dachs
service postgresql start && \
    date && \
    sleep 20 && \
    ifconfig && \
    gavo serve debug

